#include "Camera.h"
#include "../lib/glm/detail/func_trigonometric.hpp"
#include "../lib/glm/detail/func_geometric.hpp"

void Camera::updateCameraVectors()
{
	Forward.setX(cos(glm::radians(Yaw)) * cos(glm::radians(Pitch)));
	Forward.setY(sin(glm::radians(Pitch)));
	Forward.setZ(sin(glm::radians(Yaw)) * cos(glm::radians(Pitch)));
	Forward = glm::normalize(Forward); // 
	// Forward = MathUtils

	// also re-calculate the Right and Up vector
	Right = glm::normalize(glm::cross(Forward, WorldUp));  // normalize the vectors, because their length gets closer to 0 the more you look up or down which results in slower movement.
	Up = glm::normalize(glm::cross(Right, Forward));
}

Camera::Camera(const Vec3 &initialPosition) :
	START_POS(initialPosition), position(initialPosition) {}

void Camera::move(const Vec3 &values) {
	position += values;
}
void Camera::zoom(float value) {
	fov -= value;
	if (fov < 0.1f) {
		fov = 0.1f;
	}
	else if (fov > 179.0f) {
		fov = 179.0f;
	}
}
void Camera::reset() {
	position = START_POS;
	fov = START_FOV;
}

Mat4 Camera::getViewMatrix() const {
	return MathUtils::MatGen::lookAt(
		position,
		Vec3(position.getX(), position.getY(), 1.0f),
		Vec3(0.0f, 1.0f, 0.0f)
	);
}
Mat4 Camera::getProjectionMatrix(const Window *window) const {
	return MathUtils::MatGen::perspective<float>(
		MathUtils::toRadians(fov),
		(float)window->getWidth(),
		(float)window->getHeight(),
		2.0f,
		20.0f
	);
}
void Camera::Reset(glm::vec3 position, float yaw, float pitch, float targetDistance)
{
	Yaw = yaw;
	Pitch = pitch;
	Theta = pitch + 90;
	Phi = 0;
	Zoom = 45;
	Target = position;
	TargetDistance = targetDistance;
	Position = position - TargetDistance * Forward;
	updateCameraVectors();
}

